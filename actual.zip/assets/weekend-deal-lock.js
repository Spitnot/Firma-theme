/**
 * Weekend Deal Quantity Lock
 * 
 * This script prevents quantity changes for weekend deal items
 * in both the cart and checkout pages.
 */

(function() {
  'use strict';
  
  // Track locked items
  let lockedItems = new Set();
  
  // Lock quantity inputs for weekend deal items
  function lockWeekendDealQuantities() {
    // Check if we're on cart page
    if (window.location.pathname.includes('/cart')) {
      const cartUrl = window.Shopify && window.Shopify.routes ? window.Shopify.routes.cart_url + '.js' : '/cart.js';
      fetch(cartUrl)
        .then(response => response.json())
        .then(cart => {
          cart.items.forEach((item, index) => {
            // Check if item has weekend deal property
            if (item.properties && (item.properties._weekend_deal === 'true' || item.properties._quantity_locked === 'true')) {
              lockedItems.add(item.key);
              lockCartItem(index, item);
              
              // Force quantity back to 1 if it's not
              if (item.quantity !== 1) {
                updateCartItemQuantity(item.key, 1);
              }
            }
          });
        });
    }
  }
  
  // Update cart item quantity via API
  function updateCartItemQuantity(key, quantity) {
    const updateUrl = window.Shopify && window.Shopify.routes 
      ? window.Shopify.routes.cart_change_url + '.js'
      : '/cart/change.js';
    
    fetch(updateUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: key,
        quantity: quantity
      })
    })
    .then(response => response.json())
    .then(() => {
      // Reload cart to show correct quantity
      if (typeof window.location !== 'undefined') {
        window.location.reload();
      }
    })
    .catch(err => {
      console.error('Failed to reset quantity:', err);
    });
  }
  
  // Lock specific cart item
  function lockCartItem(index, item) {
    // Find quantity input for this item (common selectors across themes)
    const selectors = [
      `[name="updates[${item.key}]"]`,
      `[name="updates[${item.variant_id}]"]`,
      `[data-index="${index + 1}"] input[type="number"]`,
      `[data-index="${index}"] input[type="number"]`,
      `.cart__row:nth-child(${index + 1}) input[type="number"]`,
      `[data-variant-id="${item.variant_id}"] input[type="number"]`,
      `[data-cart-item-key="${item.key}"] input[type="number"]`,
      `input[data-quantity-input][value="${item.quantity}"]`
    ];
    
    let quantityInput = null;
    for (let selector of selectors) {
      const inputs = document.querySelectorAll(selector);
      for (let input of inputs) {
        // Check if this input is near the product with this variant
        const parent = input.closest('[data-cart-item], .cart-item, .cart__item, [class*="cart-item"]');
        if (parent) {
          const productLink = parent.querySelector('a[href*="/products/"]');
          if (productLink && productLink.href.includes(item.handle || item.product_title)) {
            quantityInput = input;
            break;
          }
        }
      }
      if (quantityInput) break;
    }
    
    if (quantityInput) {
      // Force value to 1
      quantityInput.value = 1;
      
      // Disable the input completely
      quantityInput.disabled = true;
      quantityInput.readOnly = true;
      quantityInput.setAttribute('readonly', 'readonly');
      quantityInput.setAttribute('disabled', 'disabled');
      quantityInput.style.opacity = '0.6';
      quantityInput.style.cursor = 'not-allowed';
      quantityInput.style.pointerEvents = 'none';
      
      // Prevent all events
      ['input', 'change', 'keydown', 'keyup', 'keypress', 'click', 'focus'].forEach(eventType => {
        quantityInput.addEventListener(eventType, function(e) {
          e.preventDefault();
          e.stopPropagation();
          this.value = 1;
          return false;
        }, true);
      });
      
      // Add visual indicator
      const parent = quantityInput.closest('.cart-item__quantity, .cart__item, .cart-item, [class*="quantity"]');
      if (parent && !parent.querySelector('.weekend-deal-lock-notice')) {
        const notice = document.createElement('div');
        notice.className = 'weekend-deal-lock-notice';
        notice.style.cssText = 'font-size: 12px; color: #ef4444; margin-top: 4px; font-weight: 500;';
        notice.textContent = '🔒 Weekend Deal - Qty locked to 1';
        parent.appendChild(notice);
      }
      
      // Hide and disable increment/decrement buttons
      const quantityWrapper = quantityInput.closest('[class*="quantity"], .quantity-selector, .cart-item__quantity-wrapper');
      if (quantityWrapper) {
        const buttons = quantityWrapper.querySelectorAll('button, [class*="plus"], [class*="minus"], [class*="increment"], [class*="decrement"], [type="button"]');
        buttons.forEach(btn => {
          btn.style.display = 'none';
          btn.disabled = true;
          btn.style.pointerEvents = 'none';
          
          // Prevent all click events
          btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
          }, true);
        });
      }
    }
  }
  
  // Prevent quantity changes via API
  function interceptCartAPI() {
    // Store original fetch
    const originalFetch = window.fetch;
    
    window.fetch = function(...args) {
      const [url, options] = args;
      
      // Intercept cart update/change requests
      if (url && (url.includes('/cart/update') || url.includes('/cart/change') || url.includes('/cart/add'))) {
        // Check if trying to update a locked item
        if (options && options.body) {
          try {
            const body = typeof options.body === 'string' ? JSON.parse(options.body) : options.body;
            
            // If updating locked item, force quantity to 1
            if (body.id && lockedItems.has(body.id)) {
              body.quantity = 1;
              options.body = JSON.stringify(body);
            }
            
            // If batch updating, fix locked items
            if (body.updates) {
              Object.keys(body.updates).forEach(key => {
                if (lockedItems.has(key)) {
                  body.updates[key] = 1;
                }
              });
              options.body = JSON.stringify(body);
            }
          } catch (e) {
            // If we can't parse, let it through
          }
        }
        
        return originalFetch(...args).then(async response => {
          if (response.ok) {
            // Re-lock quantities after update
            setTimeout(lockWeekendDealQuantities, 100);
            setTimeout(lockWeekendDealQuantities, 500);
          }
          return response;
        });
      }
      
      return originalFetch(...args);
    };
  }
  
  // Prevent form-based updates
  function preventFormUpdates() {
    document.addEventListener('submit', function(e) {
      const form = e.target;
      
      // Check if it's a cart update form
      if (form.action && (form.action.includes('/cart') || form.action.includes('cart'))) {
        // Get all quantity inputs in the form
        const quantityInputs = form.querySelectorAll('input[name^="updates"]');
        
        quantityInputs.forEach(input => {
          // Extract the key from input name: updates[key]
          const keyMatch = input.name.match(/updates\[([^\]]+)\]/);
          if (keyMatch) {
            const key = keyMatch[1];
            if (lockedItems.has(key)) {
              // Force it to stay at 1
              input.value = 1;
            }
          }
          
          // Also check if input itself is disabled
          if (input.disabled || input.readOnly) {
            input.value = 1;
          }
        });
      }
    }, true);
    
    // Also prevent individual input changes
    document.addEventListener('change', function(e) {
      const input = e.target;
      if (input.name && input.name.startsWith('updates[')) {
        // Check if this is a locked item
        const keyMatch = input.name.match(/updates\[([^\]]+)\]/);
        if (keyMatch && lockedItems.has(keyMatch[1])) {
          input.value = 1;
          e.preventDefault();
          e.stopPropagation();
        }
      }
    }, true);
  }
  
  // Observe DOM changes (for AJAX carts)
  function observeCartChanges() {
    const cartSelectors = [
      'cart-drawer',
      '[id*="cart"]',
      '[class*="cart"]',
      'aside',
      '[data-cart]',
      'body'
    ];
    
    let cartElement = null;
    for (let selector of cartSelectors) {
      cartElement = document.querySelector(selector);
      if (cartElement) break;
    }
    
    if (cartElement && window.MutationObserver) {
      const observer = new MutationObserver(function(mutations) {
        // Debounce the lock function
        clearTimeout(window.lockTimeout);
        window.lockTimeout = setTimeout(() => {
          lockWeekendDealQuantities();
        }, 100);
      });
      
      observer.observe(cartElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['value', 'disabled']
      });
    }
  }
  
  // Additional safeguard: Monitor and correct quantities every second
  function continuousMonitoring() {
    setInterval(() => {
      if (window.location.pathname.includes('/cart')) {
        // Check all quantity inputs
        document.querySelectorAll('input[type="number"][name^="updates"]').forEach(input => {
          if (input.disabled || input.readOnly) {
            if (input.value !== '1') {
              input.value = 1;
            }
          }
        });
      }
    }, 1000);
  }
  
  // Initialize when DOM is ready
  function init() {
    lockWeekendDealQuantities();
    interceptCartAPI();
    preventFormUpdates();
    observeCartChanges();
    continuousMonitoring();
    
    // Re-lock on cart updates (common events)
    document.addEventListener('cart:updated', lockWeekendDealQuantities);
    document.addEventListener('cart:refresh', lockWeekendDealQuantities);
    document.addEventListener('cart:change', lockWeekendDealQuantities);
    
    // Re-lock periodically for safety
    setInterval(lockWeekendDealQuantities, 2000);
  }
  
  // Run on page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
  // Re-run on Shopify section rendering (for theme editor)
  document.addEventListener('shopify:section:load', init);
  document.addEventListener('shopify:section:reorder', init);
  
})();
