/**
 * ============================================
 * CUSTOM: Image Switcher FINAL para Ritual
 * ============================================
 */

(function() {
  'use strict';

  let productData = null;

  // Obtener datos del producto
  function getProductData() {
    if (productData) return productData;

    // Buscar el JSON del producto en varios lugares posibles
    const selectors = [
      'script[data-product-json]',
      'script[type="application/json"][data-product-json]',
      '[data-product-json]',
      'script#product-json',
      'script[data-section-type="product"]'
    ];

    for (let selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        try {
          const text = element.textContent || element.innerHTML;
          productData = JSON.parse(text);
          console.log('Custom Image Switcher: Product data found!', productData);
          return productData;
        } catch (e) {
          console.log('Custom Image Switcher: Failed to parse', selector);
        }
      }
    }

    // Si no lo encontramos en JSON, buscar en window
    if (window.ShopifyAnalytics && window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.product) {
      productData = window.ShopifyAnalytics.meta.product;
      console.log('Custom Image Switcher: Product data from ShopifyAnalytics');
      return productData;
    }

    console.log('Custom Image Switcher: Product data not found anywhere');
    return null;
  }

  // Esperar e inicializar
  function init() {
    const variantInputs = document.querySelectorAll('input[name*="Color"], input[type="radio"]');
    
    if (variantInputs.length === 0) {
      console.log('Custom Image Switcher: No inputs found, retrying...');
      setTimeout(init, 100);
      return;
    }

    console.log('Custom Image Switcher: Found', variantInputs.length, 'inputs');

    // Obtener datos del producto
    getProductData();

    // Escuchar cambios
    variantInputs.forEach(function(input) {
      input.addEventListener('change', function() {
        console.log('Custom Image Switcher: Changed to', input.value);
        handleChange(input);
      });
    });

    console.log('Custom Image Switcher: Ready!');
  }

  function handleChange(input) {
    const variantId = input.getAttribute('data-variant-id');
    
    if (!variantId) {
      console.log('Custom Image Switcher: No variant ID');
      return;
    }

    console.log('Custom Image Switcher: Variant ID:', variantId);

    const product = getProductData();
    
    if (!product || !product.variants) {
      console.log('Custom Image Switcher: No product data');
      return;
    }

    const variant = product.variants.find(v => v.id.toString() === variantId);
    
    if (!variant) {
      console.log('Custom Image Switcher: Variant not found');
      return;
    }

    console.log('Custom Image Switcher: Variant:', variant);

    if (!variant.featured_media) {
      console.log('Custom Image Switcher: No featured media');
      return;
    }

    const mediaId = variant.featured_media.id.toString();
    console.log('Custom Image Switcher: Media ID:', mediaId);

    goToSlide(mediaId);
  }

  function goToSlide(mediaId) {
    const slideshow = document.querySelector('slideshow-component');
    
    if (!slideshow) {
      console.log('Custom Image Switcher: No slideshow');
      return;
    }

    const slides = slideshow.querySelectorAll('slideshow-slide');
    let target = -1;

    slides.forEach(function(slide, i) {
      const media = slide.querySelector('[data-media-id]');
      if (media && media.getAttribute('data-media-id') === mediaId) {
        target = i;
      }
    });

    if (target === -1) {
      console.log('Custom Image Switcher: Slide not found');
      return;
    }

    const current = getCurrentSlide(slideshow);
    console.log('Custom Image Switcher: Go from', current, 'to', target);

    const diff = target - current;
    
    if (diff === 0) return;

    const button = diff > 0 
      ? slideshow.querySelector('.slideshow-control--next')
      : slideshow.querySelector('.slideshow-control--previous');

    if (!button) return;

    for (let i = 0; i < Math.abs(diff); i++) {
      setTimeout(function() {
        button.click();
      }, i * 150);
    }
  }

  function getCurrentSlide(slideshow) {
    const slides = slideshow.querySelectorAll('slideshow-slide');
    
    for (let i = 0; i < slides.length; i++) {
      if (slides[i].getAttribute('aria-hidden') === 'false') {
        return i;
      }
    }
    
    return 0;
  }

  // Iniciar
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();